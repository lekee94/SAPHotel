﻿using Microsoft.Extensions.DependencyInjection;
using SAPHotel.Domain.Services;
using SAPHotel.Domain.Services.Impl;

namespace SAPHotel.Domain.DependencyInjection
{
    public static class DependencyConfiguration
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddScoped<IRoomReservation, RoomReservation>();
            services.AddScoped<IReservationAvailability, ReservationAvailability>();
            services.AddScoped<IReservationInsertion, ReservationInsertion>();
        }

    }
}
