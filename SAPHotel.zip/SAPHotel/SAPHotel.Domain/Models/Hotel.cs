﻿using System.Collections.Generic;

namespace SAPHotel.Domain.Models
{
    public class Hotel
    {
        private const int _numberOfRooms = 1000;
        public IList<Room> HotelRooms { get; private set; }

        public Hotel()
        {
            HotelRooms = new List<Room>();

            for (int i = 0; i < _numberOfRooms; i++)
            {
                HotelRooms.Add(new Room());
            }
        }
    }
}
