﻿using SAPHotel.Domain.BuildingBlocks;
using System.Collections.Generic;

namespace SAPHotel.Domain.Models
{
    public class Room : Entity
    {
        public IList<Reservation> Reservations { get; }

        public Room()
        {
            Reservations = new List<Reservation>();
        }
    }
}
