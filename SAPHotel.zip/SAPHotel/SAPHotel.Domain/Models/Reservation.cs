﻿using SAPHotel.Domain.BuildingBlocks;

namespace SAPHotel.Domain.Models
{
    public class Reservation : Entity
    {
        public DateRange BookingPeriod { get; private set; }

        public Reservation(DateRange bookingPerion) => BookingPeriod = bookingPerion;
    }
}
