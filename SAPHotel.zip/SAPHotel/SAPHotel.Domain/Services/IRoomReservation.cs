﻿using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.Models;
using System.Collections.Generic;

namespace SAPHotel.Domain.Services
{
    public interface IRoomReservation
    {
        bool MakeReservation(DateRange dateRange, IList<Room> rooms);
    }
}
