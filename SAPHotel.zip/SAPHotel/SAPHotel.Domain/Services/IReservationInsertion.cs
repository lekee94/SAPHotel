﻿using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.Models;

namespace SAPHotel.Domain.Services
{
    public interface IReservationInsertion
    {
        bool AddReservation(Room room, DateRange newReservation);
    }
}
