﻿using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.Models;
using System.Collections.Generic;

namespace SAPHotel.Domain.Services.Impl
{
    public class RoomReservation : IRoomReservation
    {
        private readonly IReservationInsertion _reservationInsertion;

        public RoomReservation(IReservationInsertion reservationInsertion)
        {
            _reservationInsertion = reservationInsertion;
        }

        public bool MakeReservation(DateRange dateRange, IList<Room> rooms)
        {
            foreach (Room room in rooms)
            {
                if (!_reservationInsertion.AddReservation(room, dateRange))
                    continue;

                return true;
            }
            return false;
        }
    }
}
