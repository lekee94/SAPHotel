﻿using SAPHotel.Domain.BuildingBlocks;

namespace SAPHotel.Domain.Services.Impl
{
    public class ReservationAvailability : IReservationAvailability
    {
        public bool Overlaps(DateRange existingReservation, DateRange reservation) =>
            !((existingReservation.StartDate > reservation.StartDate && existingReservation.StartDate > reservation.EndDate)
            || (existingReservation.EndDate < reservation.StartDate && existingReservation.EndDate < reservation.EndDate));
    }
}
