﻿using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.Models;
using System.Linq;

namespace SAPHotel.Domain.Services.Impl
{
    public class ReservationInsertion : IReservationInsertion
    {
        private readonly IReservationAvailability _reservationAvailability;

        public ReservationInsertion(IReservationAvailability reservationAvailability)
        {
            _reservationAvailability = reservationAvailability;
        }

        public bool AddReservation(Room room, DateRange newReservation)
        {
            if (!room.Reservations.Any(r => _reservationAvailability.Overlaps(r.BookingPeriod, newReservation)))
            {
                room.Reservations.Add(new Reservation(newReservation));

                return true;
            }
            return false;
        }
    }
}
