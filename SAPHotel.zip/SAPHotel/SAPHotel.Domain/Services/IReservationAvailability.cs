﻿using SAPHotel.Domain.BuildingBlocks;

namespace SAPHotel.Domain.Services
{
    public interface IReservationAvailability
    {
        bool Overlaps(DateRange existingReservation, DateRange reservation);
    }
}
