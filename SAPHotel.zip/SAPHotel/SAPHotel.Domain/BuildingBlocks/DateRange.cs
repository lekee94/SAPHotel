﻿using SAPHotel.Domain.BuildingBlocks.Exceptions;

namespace SAPHotel.Domain.BuildingBlocks
{
    public class DateRange
    {
        public int StartDate { get; set; }

        public int EndDate { get; private set; }

        public DateRange(int startDate, int endDate)
        {
            if (!IsValidDateRange(startDate, endDate))
                throw new InvalidDateRangeException("Invalid input...");

            StartDate = startDate;
            EndDate = endDate;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is DateRange)) return false;
            return (obj as DateRange).StartDate == StartDate && (obj as DateRange).EndDate == EndDate;
        }

        public override string ToString() => $"{StartDate} - {EndDate}";

        public override int GetHashCode() => base.GetHashCode();

        private bool IsValidDateRange(int startDate, int endDate) => endDate >= startDate && startDate >= 0 && endDate <= 364;
    }
}
