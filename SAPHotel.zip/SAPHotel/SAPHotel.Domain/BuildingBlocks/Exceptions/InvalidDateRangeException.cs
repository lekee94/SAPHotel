﻿using System;

namespace SAPHotel.Domain.BuildingBlocks.Exceptions
{
    public class InvalidDateRangeException : Exception
    {
        public InvalidDateRangeException()
        {
        }

        public InvalidDateRangeException(string message) : base(message)
        {
        }
    }
}
