﻿using System;

namespace SAPHotel.Domain.BuildingBlocks
{
    public abstract class Entity
    {
        public string Id { get; protected set; }

        public Entity() => Id = Guid.NewGuid().ToString();

        public Entity(string id) => Id = id;

        public override bool Equals(object obj)
        {
            if (!(obj is Entity)) return false;
            return (obj as Entity).Id == Id;
        }

        public override int GetHashCode() => base.GetHashCode();

        public override string ToString() => Id;
    }
}
