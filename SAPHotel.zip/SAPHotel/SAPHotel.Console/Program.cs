﻿using Microsoft.Extensions.DependencyInjection;
using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.DependencyInjection;
using SAPHotel.Domain.Models;
using SAPHotel.Domain.Services;

namespace SAPHotel.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();
            services.AddServices();
            var provider = services.BuildServiceProvider();

            var roomReservation = provider.GetService<IRoomReservation>();

            var hotel = new Hotel();

            roomReservation.MakeReservation(new DateRange(1, 3), hotel.HotelRooms);
        }
    }
}
