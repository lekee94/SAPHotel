﻿using Moq;
using SAPHotel.Domain.Models;
using SAPHotel.Domain.Services;
using System.Collections.Generic;

namespace SAPHotel.Test
{
    public class BaseSettings
    {
        protected IRoomReservation _roomReservation;
        protected IReservationAvailability _reservationAvailability;
        protected IReservationInsertion _reservationInsertion;

        protected Mock<IReservationInsertion> _reservationInsertionMock;
        protected Mock<IReservationAvailability> _reservationAvailablilityMock;

        protected IList<Room> _hotelRooms;

        protected IList<Room> MockHotelRooms(int numberOfRooms)
        {
            _hotelRooms = new List<Room>();

            for (int i = 0; i < numberOfRooms; i++)
            {
                _hotelRooms.Add(new Room());
            }
            return _hotelRooms;
        }
    }
}
