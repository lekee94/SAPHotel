﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.BuildingBlocks.Exceptions;

namespace SAPHotel.Test.BuildingBlocksTests
{
    [TestClass]
    public class DateRangeTests
    {
        [TestMethod]
        [Description("Passed valid values to DateRange constructor which should create new DateRange object")]
        [DataRow(1, 3)]
        public void CreateDateRange_ValidInput_CreatesNewDateRange(int startDate, int endDate)
        {
            //Act
            var validDateRange = new DateRange(startDate, endDate);

            //Assert
            Assert.IsNotNull(validDateRange);
            Assert.IsTrue(validDateRange.StartDate == startDate && validDateRange.EndDate == endDate);
        }

        [TestMethod]
        [Description("Passed values less than valid to DateRange constructor which should throw InvalidDateRangeException")]
        [DataRow(-4, 2)]
        public void CreateDateRange_InputLessThanValid_ThrowsInvalidDateRangeException(int startDate, int endDate)
        {

            Assert.ThrowsException<InvalidDateRangeException>(() => new DateRange(startDate, endDate));
        }

        [TestMethod]
        [Description("Passed values greater than valid to DateRange constructor which should throw InvalidDateRangeException")]
        [DataRow(200, 400)]
        public void CreateDateRange_InputGreaterThanValid_ThrowsInvalidDateRangeException(int startDate, int endDate)
        {

            Assert.ThrowsException<InvalidDateRangeException>(() => new DateRange(startDate, endDate));
        }

        [TestMethod]
        [Description("Passed values where startDate is greater than endDate to DateRange constructor which should throw InvalidDateRangeException")]
        [DataRow(3, 2)]
        public void CreateDateRange_StartDateGreaterThanEndDate_ThrowsInvalidDateRangeException(int startDate, int endDate)
        {
            Assert.ThrowsException<InvalidDateRangeException>(() => new DateRange(startDate, endDate));
        }
    }
}
