﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.BuildingBlocks.Exceptions;
using SAPHotel.Domain.DependencyInjection;
using SAPHotel.Domain.Services;

namespace SAPHotel.Test
{
    [TestClass]
    public class TestCases : BaseSettings
    {

        [TestInitialize]
        public void TestInitialize()
        {
            var services = new ServiceCollection();
            services.AddServices();
            var provider = services.BuildServiceProvider();

            _roomReservation = provider.GetService<IRoomReservation>();
        }

        [TestMethod]
        [Description("MakeReservation operation will try to book a room with values less than valid which wont be possible and InvalidDateRangeException will be thrown")]
        [DataRow(-4, 2)]
        [DataRow(200, 400)]
        [DataRow(3, 2)]
        public void MakeReservation_InvalidInput_ThrowsInvalidDateRangeException(int startDate, int endDate)
        {
            //Arrange
            _hotelRooms = MockHotelRooms(1);

            //Act and Assert
            Assert.ThrowsException<InvalidDateRangeException>(() => _roomReservation.MakeReservation(new DateRange(startDate, endDate), _hotelRooms));
        }

        [TestMethod]
        [Description("MakeReservation operation will book rooms for all given reservation dates and will return true for every made reservation")]
        public void MakeReservation_ValidInput_AllRoomsAreBooked()
        {
            //Arrange
            var roomReservationResponses = new bool[6];
            _hotelRooms = MockHotelRooms(3);

            //Act
            roomReservationResponses[0] = _roomReservation.MakeReservation(new DateRange(0, 5), _hotelRooms);
            roomReservationResponses[1] = _roomReservation.MakeReservation(new DateRange(7, 13), _hotelRooms);
            roomReservationResponses[2] = _roomReservation.MakeReservation(new DateRange(3, 9), _hotelRooms);
            roomReservationResponses[3] = _roomReservation.MakeReservation(new DateRange(5, 7), _hotelRooms);
            roomReservationResponses[4] = _roomReservation.MakeReservation(new DateRange(6, 6), _hotelRooms);
            roomReservationResponses[5] = _roomReservation.MakeReservation(new DateRange(0, 4), _hotelRooms);

            //Assert
            foreach (var response in roomReservationResponses)
            {
                Assert.IsTrue(response);
            }
        }

        [TestMethod]
        [Description("MakeReservation operation will decline reservation since there is no free room for given period")]
        public void MakeReservation_RoomAlreadyBooked_ReturnsFalseForAlreadyBookedRoom()
        {
            //Arrange
            var roomReservationResponses = new bool[4];
            _hotelRooms = MockHotelRooms(3);

            //Act
            roomReservationResponses[0] = _roomReservation.MakeReservation(new DateRange(1, 3), _hotelRooms);
            roomReservationResponses[1] = _roomReservation.MakeReservation(new DateRange(2, 5), _hotelRooms);
            roomReservationResponses[2] = _roomReservation.MakeReservation(new DateRange(1, 9), _hotelRooms);
            roomReservationResponses[3] = _roomReservation.MakeReservation(new DateRange(0, 15), _hotelRooms);

            //Assert
            Assert.IsFalse(roomReservationResponses[3]);
        }

        [TestMethod]
        [Description("MakeReservation operation will accept booking after it has declined previous request")]
        public void MakeReservation_BookAfterDeclinedRequest_ReturnsTrueForCallAfterDeclined()
        {
            //Arrange
            var roomReservationResponses = new bool[5];
            _hotelRooms = MockHotelRooms(3);

            //Act
            roomReservationResponses[0] = _roomReservation.MakeReservation(new DateRange(1, 3), _hotelRooms);
            roomReservationResponses[1] = _roomReservation.MakeReservation(new DateRange(0, 15), _hotelRooms);
            roomReservationResponses[2] = _roomReservation.MakeReservation(new DateRange(1, 9), _hotelRooms);
            roomReservationResponses[3] = _roomReservation.MakeReservation(new DateRange(3, 5), _hotelRooms);
            roomReservationResponses[4] = _roomReservation.MakeReservation(new DateRange(4, 9), _hotelRooms);

            //Assert
            Assert.IsFalse(roomReservationResponses[3]);
            Assert.IsTrue(roomReservationResponses[4]);
        }

        [TestMethod]
        [Description("MakeReservation operation will accept booking when room is available for that date and decline when not")]
        public void MakeReservation_ComplexRequests_ReturnsTrueWhenRoomIsAvailableAndFalseWhenRoomIsUnavailable()
        {
            //Arrange
            var roomReservationResponses = new bool[9];
            _hotelRooms = MockHotelRooms(2);

            //Act
            roomReservationResponses[0] = _roomReservation.MakeReservation(new DateRange(1, 3), _hotelRooms);
            roomReservationResponses[1] = _roomReservation.MakeReservation(new DateRange(0, 4), _hotelRooms);
            roomReservationResponses[2] = _roomReservation.MakeReservation(new DateRange(2, 3), _hotelRooms);
            roomReservationResponses[3] = _roomReservation.MakeReservation(new DateRange(5, 5), _hotelRooms);
            roomReservationResponses[4] = _roomReservation.MakeReservation(new DateRange(4, 10), _hotelRooms);
            roomReservationResponses[5] = _roomReservation.MakeReservation(new DateRange(10, 10), _hotelRooms);
            roomReservationResponses[6] = _roomReservation.MakeReservation(new DateRange(6, 7), _hotelRooms);
            roomReservationResponses[7] = _roomReservation.MakeReservation(new DateRange(8, 10), _hotelRooms);
            roomReservationResponses[8] = _roomReservation.MakeReservation(new DateRange(8, 9), _hotelRooms);

            //Assert
            Assert.IsTrue(roomReservationResponses[0]);
            Assert.IsTrue(roomReservationResponses[1]);
            Assert.IsFalse(roomReservationResponses[2]);
            Assert.IsTrue(roomReservationResponses[3]);
            Assert.IsFalse(roomReservationResponses[4]);
            Assert.IsTrue(roomReservationResponses[5]);
            Assert.IsTrue(roomReservationResponses[6]);
            Assert.IsTrue(roomReservationResponses[7]);
            Assert.IsTrue(roomReservationResponses[8]);
        }

    }
}
