﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.DependencyInjection;
using SAPHotel.Domain.Services;

namespace SAPHotel.Test.ServiceTests
{
    [TestClass]
    public class ReservationAvailabilityTests : BaseSettings
    {
        [TestInitialize]
        public void Initialize()
        {
            var services = new ServiceCollection();
            services.AddServices();
            var provider = services.BuildServiceProvider();

            _reservationAvailability = provider.GetService<IReservationAvailability>();
        }

        [TestMethod]
        [Description("Overlaps returns true if two DateRanges overlap")]
        [DataRow(2, 5, 1, 3)]
        public void Overlaps_TwoDateRangesOverlap_ReturnsTrue(int existingStartDate, int existingEndDate, int reservationStartDate, int reservationEndDate)
        {
            //Arrange
            var existingBooking = new DateRange(existingStartDate, existingEndDate);
            var reservation = new DateRange(reservationStartDate, reservationEndDate);

            //Act
            var response = _reservationAvailability.Overlaps(existingBooking, reservation);

            //Assert
            Assert.IsTrue(response);
        }

        [TestMethod]
        [Description("Overlaps returns false if two DateRanges dont overlap")]
        [DataRow(1, 3, 4, 5)]
        public void Overlaps_TwoDateRangesDontOverlap_ReturnsFalse(int existingStartDate, int existingEndDate, int reservationStartDate, int reservationEndDate)
        {
            //Arrange
            var existingBooking = new DateRange(existingStartDate, existingEndDate);
            var reservation = new DateRange(reservationStartDate, reservationEndDate);

            //Act
            var response = _reservationAvailability.Overlaps(existingBooking, reservation);

            //Assert
            Assert.IsFalse(response);
        }
    }
}
