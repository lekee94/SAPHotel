﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.Models;
using SAPHotel.Domain.Services;
using SAPHotel.Domain.Services.Impl;

namespace SAPHotel.Test.ServiceTests
{
    [TestClass]
    public class RoomReservationTests : BaseSettings
    {
        [TestInitialize]
        public void Initialize()
        {
            _reservationInsertionMock = new Mock<IReservationInsertion>();
            _roomReservation = new RoomReservation(_reservationInsertionMock.Object);
            _hotelRooms = MockHotelRooms(1000);
        }

        [TestMethod]
        [Description("AddReservation of ReservationInsertion service is returning True which should allow MakeReservation operation to book a room and returns True")]
        public void MakeReservation_ValidValues_ReturnsTrue()
        {
            //Arrange
            _reservationInsertionMock.Setup(r => r.AddReservation(It.IsAny<Room>(), It.IsAny<DateRange>())).Returns(true);

            //Act
            var roomReservationResponse = _roomReservation.MakeReservation(It.IsAny<DateRange>(), _hotelRooms);

            //Assert
            Assert.IsTrue(roomReservationResponse);
        }

        [TestMethod]
        [Description("AddReservation of ReservationInsertion service is returning False which shouldn't allow MakeReservation operation to book a room and returns False")]
        public void MakeReservation_FullRooms_ReturnsFalse()
        {
            //Arrange
            _reservationInsertionMock.Setup(r => r.AddReservation(It.IsAny<Room>(), It.IsAny<DateRange>())).Returns(false);

            //Act
            var roomReservationResponse = _roomReservation.MakeReservation(It.IsAny<DateRange>(), _hotelRooms);

            //Assert
            Assert.IsFalse(roomReservationResponse);
        }
    }
}
