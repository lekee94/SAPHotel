﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SAPHotel.Domain.BuildingBlocks;
using SAPHotel.Domain.Models;
using SAPHotel.Domain.Services;
using SAPHotel.Domain.Services.Impl;
using System.Linq;

namespace SAPHotel.Test.ServiceTests
{
    [TestClass]
    public class ReservationInsertionTests : BaseSettings
    {
        private Room room;

        [TestInitialize]
        public void Initialize()
        {
            _reservationAvailablilityMock = new Mock<IReservationAvailability>();
            _reservationInsertion = new ReservationInsertion(_reservationAvailablilityMock.Object);

            room = new Room();
        }

        [TestMethod]
        [Description("AddReservation will add Reservation to Room when given Reservation date doesnt Overlap with existing reservations")]
        [DataRow(1, 3)]
        public void AddReservation_DateRangesDoesntOverlap_ReturnsTrueAndReservationIsAddedToTheRoom(int startDate, int endDate)
        {
            //Arrage
            _reservationAvailablilityMock.Setup(r => r.Overlaps(It.IsAny<DateRange>(), It.IsAny<DateRange>())).Returns(false);
            room.Reservations.Add(new Reservation(new DateRange(1, 1)));
            var reservation = new DateRange(startDate, endDate);

            //Act
            var reservationInsertionResponse = _reservationInsertion.AddReservation(room, reservation);

            //Assert
            Assert.IsTrue(reservationInsertionResponse);
            Assert.IsTrue(room.Reservations.Count() > 1);
        }

        [TestMethod]
        [Description("AddReservation will not add Reservation to Room when given ReservationDate Overlaps with any existing reservation")]
        [DataRow(1, 3)]
        public void AddReservation_DateRangesOverlap_ReturnsFalseAndReservationIsNotAddedToTheRoom(int startDate, int endDate)
        {
            //Arrage
            _reservationAvailablilityMock.Setup(r => r.Overlaps(It.IsAny<DateRange>(), It.IsAny<DateRange>())).Returns(true);
            room.Reservations.Add(new Reservation(new DateRange(1, 1)));
            var reservation = new DateRange(startDate, endDate);

            //Act
            var reservationInsertionResponse = _reservationInsertion.AddReservation(room, reservation);

            //Assert
            Assert.IsFalse(reservationInsertionResponse);
            Assert.IsTrue(room.Reservations.Count() == 1);
        }
    }
}
